The code in this directory does not work. Currently revamping the guy's code in RasPi-Dc-Motor-Class to work with our motor driver which a PWM and DIR pin, instead of 2 PWM pins.
