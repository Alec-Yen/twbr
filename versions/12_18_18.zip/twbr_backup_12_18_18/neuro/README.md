This repo will have code that implements the application of our project for the neuromorphic group.
