12/7/2018
Best combo with battery at bottom: 60 .5 .5
Max Speed: 60, Sample Time: 0.01 s
Higher Kp increased oscillation speed
Higher Kd increased oscillations more?
IMU placement and tilt is CRITICAL. Need to secure
Still trying to figure out what Ki does (seems to reduce oscillations?)
Battery placement didn't make a huge difference between middle and bottom layer
https://www.cs.cmu.edu/afs/cs.cmu.edu/academic/class/16311/www/s18/labs/lab04/previous_versions/handout2016.pdf



TO DO:
Switch to Roboclaw
Secure IMU so it is as close to aligned as possible
Get precise starting angle
3D print new mounting to put Pi and motor driver on middle layer
3D print entire chassis
Add training wheels or similar


LATER:
Write code to handle SIGINT


DEAN'S SUGGESTIONS
Increase max speed
Use encoder to account for varying surfaces
Eventually control motors separately
