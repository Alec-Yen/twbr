This includes code for the roboclaw, with both cpp and python variants. cpp code doesn't work currently.
