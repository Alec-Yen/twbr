# Two-Wheel Balancing Robot

Classic application from control theory of the inverted pendulum.

IMU cpp: https://github.com/jrowberg/i2cdevlib
Motor Driver cpp: https://github.com/Steve136/RasPi-DC-Motor-Class
