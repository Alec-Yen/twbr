#include "TWAE.hpp"
#include "params.h"
#include <fstream>
#include <cmath>
#include <sstream>
#include <map>
#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>

using namespace std;
using namespace NeuroUtils;

int main () {
	return 0;
}


